<?php

namespace frontend\models;
use Yii;

/**
 * Login form
 */
class CategoryModel extends \yii\db\ActiveRecord
{
    public $category_id;

    public static function tableName()
    {
        return 'category';
    }
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // username and password are both required
            [['category_id'], 'required']
        ];
    }
    public function subcategory($id){
        $connection = Yii::$app -> db;
        $sql = "SELECT * FROM category where status='1' and main_category='".$id."'";
        $command= $connection -> createCommand($sql)->queryAll();
        return $command;
        
    }
    /**
     * Validates the password.
     * This method serves as the inline validation for password.
     *
     * @param string $attribute the attribute currently being validated
     * @param array $params the additional name-value pairs given in the rule
     */
}
