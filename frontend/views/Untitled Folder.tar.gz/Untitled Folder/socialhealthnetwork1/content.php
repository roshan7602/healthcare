<?php


use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
$url=Url::base();
$this->title = 'Socio-Health Network';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="container">
  <h2>Content</h2>
  
  <?php $form = ActiveForm::begin(); ?>
    
    <div class="form-group">
       <?php $dataCategory=ArrayHelper::map(\frontend\models\CategoryModel::find()->where(['status' =>'1'])->andWhere(['main_category' =>'0'])->orderBy('name')->asArray()->all(), 'category_id', 'name');
         echo $form->field($model, 'category_id')->dropDownList($dataCategory, 
             ['prompt'=>'-Choose a Category-',
              'onchange'=>'
                $.post( "'.Yii::$app->urlManager->createUrl('index.php/socialhealthnetwork/subcategory?id=').'"+$(this).val(),function(data){
                    $( "#select" ).html(data);
                });
            ']); 
         ?>
  
    </div>
    <div class="form-group">
        <label for="sel2">Subcategory</label>
        <select name="subcategory" class="form-control input-lg" id="select">
        
        </select>
    </div>
  <label for="sel2">Content</label>
    <div class="form-group">
        
        <div class="col-sm-10">
          <div class="fg-line">
            <textarea name="Content" id="descr" class="content_val" style="width:100%;  height:300px" ></textarea>
          </div>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label" for="">&nbsp;</label>
        <div class="col-sm-10">
          <div class="fg-line">
            <?= Html::submitButton('Submit', ['class' => 'submit btn btn-info  form-sub']) ?>

          </div>
        </div>
     </div>
  <?php  ActiveForm::end(); ?>
</div>

<?php
$script=<<< JS
        
        CKEDITOR.replace( 'Content',
        {
        filebrowserBrowseUrl : 'ckfinder/ckfinder.html',
        filebrowserImageBrowseUrl : '../../../web/ckeditor/ckfinder/ckfinder.html?type=Images',
        filebrowserFlashBrowseUrl : '../../../web/ckeditor/ckfinder/ckfinder.html?type=Flash',
        filebrowserUploadUrl : '../../../web/ckeditor/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
        filebrowserImageUploadUrl : '../../../web/ckeditor/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
        filebrowserFlashUploadUrl : '../../../web/ckeditor/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
        }); 
        
        
        var body_val = $('.template_body').val();
        $(".note-editable").html(body_val);
        
          
          
JS;
$this->registerJs($script);            
?> 