<div class="top-head">
    <div class="container">

        <div class="pull-left"><a href="<?php echo Yii::getAlias('@web') ?>"><img src="../images/logo.jpg"></a>
            <div class="search-box"><span>Elevating your health</span> <span class="search"><i class="fa fa-search"></i> <input name="" value="" placeholder="Search"></span></div>
        </div>

        <div class="pull-right">
            <ul class="info-list-top">
                <li> <i class="fa fa-phone"></i> 01332-256489</li>
                <li>Mohit</li>
                <li><img src="../images/msg-icon.png"></li>
                <li><i class="fa fa-bell"></i> </li>
                <li><img class="img-circle" src="../images/profile-icon.jpg"></li>
            </ul>
        </div>

    </div>
</div>