<footer class="footer">
    <div class="container">
    <div class="row">
  <div class="col-md-4"><div class="widget"><a href="<?php echo Yii::getAlias('@web') ?>"><img src="../images/footer-logo.png"><br> Elevating your health</a></div></div>
  <div class="col-md-5"><h2>About the company</h2>
<p>  Lorem ipsum dolor sit amet, consectetur Curabitur congue erat eget 
egestas condimentum. vehicula sodales. Etiam tristique nibh odio, 
interdum risus tempus at. Quisque aliquet </p>
<ul class="soc">
<li><a class="soc-facebook" href="#"></a></li>
<li><a class="soc-twitter" href="#"></a></li>
 <li><a class="soc-linkedin" href="#"></a></li>
<li><a class="soc-google" href="#"></a></li>
</ul>
<h5>To subscribe please enter your mail below</h5>
<div class="emailer">
<input type="email" name="" placeholder="Email address"> <button class="btn btn-default" type="button" onclick="">Submit</button>
</div>
<ul class="address">
<li><span><i class="fa fa-phone"></i></span> +91-9837586589</li>
<li><span><i class="fa fa-envelope"></i></span> support@helevate.com</li>
<li><span><i class="fa fa-map-marker"></i></span> S/59 Near Bihari Chowk Ramesh Nagar New Delhi 110001 </li>
 </ul>


  </div>
</div>
 
    </div>
</footer>