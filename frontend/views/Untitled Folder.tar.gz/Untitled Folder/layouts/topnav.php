 
 <?php
 use yii\helpers\Html;
 use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
    NavBar::begin([
  //      'brandLabel' => '<img src="../images/logo.jpg">',
//        'brandUrl' => Yii::$app->homeUrl,
//        'options' => [
//            'class' => 'navbar-inverse navbar-fixed-top',
//        ],
    ]);
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-left'],
        'items' => [
            ['label' => 'Health Zone', 'url' => ['/site/index']],
            ['label' => 'Socio-Health Network', 'url' => ['/site/sociohealthnetwork']],
			['label' => 'Book an Appointment', 'url' => ['/site/bookappointment']],
			['label' => 'Order Medicines', 'url' => ['/site/ordermedicines']],
			['label' => 'Health Tracker', 'url' => ['/site/healthtracker']],
			['label' => 'Home facilities', 'url' => ['/site/homefacilities']],

        ],
    ]);

 if (Yii::$app->user->isGuest) {
     $menuItems[] = ['label' => 'Signup', 'url' => ['/user/signup']];
     $menuItems[] = ['label' => 'Login', 'url' => ['/user/login']];
 } else {
     $menuItems[] = '<li>'
         . Html::beginForm(['/site/logout'], 'post')
         . Html::submitButton(
             'Logout (' . Yii::$app->user->identity->username . ')',
             ['class' => 'btn btn-link']
         )
         . Html::endForm()
         . '</li>';
 }
 echo Nav::widget([
     'options' => ['class' => 'navbar-nav navbar-right'],
     'items' => $menuItems,
 ]);
    NavBar::end();
    ?>