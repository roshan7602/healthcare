<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use frontend\assets\AppAsset;
use common\widgets\Alert;
use yii\helpers\Url;

$url=Url::base();
AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
    <?php $this->beginBody() ?>
<div class="wrap">
<div class="top-head"><div class="container">
<div class="pull-left"><a href="<?php echo Yii::getAlias('@web') ?>"><img src="<?php echo Url::base();?>/images/logo.jpg"></a>

<div class="search-box"><span>Elevating your health</span> <span class="search"><i class="fa fa-search"></i> <input name="" value="" placeholder="Search"></span></div></div>
 <div class="pull-right"><ul class="info-list-top">
 <li> <i class="fa fa-phone"></i> 01332-256489</li>
  <li>Mohit</li>
  <li><img src="<?php echo Url::base();?>/images/msg-icon.png"></li>
   <li><i class="fa fa-bell"></i> </li>
   <li><img class="img-circle" src="<?php echo Url::base();?>/images/profile-icon.jpg"></li>
   <li role="presentation"><a href="<?php echo $url;?>/index.php/site/logout">Log out</a></li>
   
 </ul>
  </div></div>
   
</div>
    <?php
    NavBar::begin([
  //      'brandLabel' => '<img src="../images/logo.jpg">',
//        'brandUrl' => Yii::$app->homeUrl,
//        'options' => [
//            'class' => 'navbar-inverse navbar-fixed-top',
//        ],
    ]);
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-left'],
        'items' => [
            ['label' => 'Health Zone', 'url' => ['/site/index']],
            ['label' => 'Socio-Health Network', 'url' => ['/site/sociohealthnetwork']],
			['label' => 'Book an Appointment', 'url' => ['/site/bookappointment']],
			['label' => 'Order Medicines', 'url' => ['/site/ordermedicines']],
			['label' => 'Health Tracker', 'url' => ['/site/healthtracker']],
			['label' => 'Home facilities', 'url' => ['/site/homefacilities']],
            //['label' => 'Contact', 'url' => ['/site/contact']],
            //Yii::$app->user->isGuest ? (
                //['label' => 'Login', 'url' => ['/site/login']]
            //) : (
                //'<li>'
               // . Html::beginForm(['/site/logout'], 'post')
                //. Html::submitButton(
                  //  'Logout (' . Yii::$app->user->identity->username . ')',
                   // ['class' => 'btn btn-link']
               // )
               // . Html::endForm()
               // . '</li>'
          //  )
        ],
    ]);
    NavBar::end();
    ?>

    <div class="page-content">
    <?php /*?>    <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?><?php */?>
        <?= $content ?>
    </div>
</div>

<footer class="footer">
    <div class="container">
    <div class="row">
  <div class="col-md-4"><div class="widget"><a href="<?php echo Yii::getAlias('@web') ?>"><img src="<?php echo Url::base();?>/images/footer-logo.png"><br> Elevating your health</a></div></div>
  <div class="col-md-5"><h2>About the company</h2>
<p>  Lorem ipsum dolor sit amet, consectetur Curabitur congue erat eget 
egestas condimentum. vehicula sodales. Etiam tristique nibh odio, 
interdum risus tempus at. Quisque aliquet </p>
<ul class="soc">
<li><a class="soc-facebook" href="#"></a></li>
<li><a class="soc-twitter" href="#"></a></li>
 <li><a class="soc-linkedin" href="#"></a></li>
<li><a class="soc-google" href="#"></a></li>
</ul>
<h5>To subscribe please enter your mail below</h5>
<div class="emailer">
<input type="email" name="" placeholder="Email address"> <button class="btn btn-default" type="button" onclick="">Submit</button>
</div>
<ul class="address">
<li><span><i class="fa fa-phone"></i></span> +91-9837586589</li>
<li><span><i class="fa fa-envelope"></i></span> support@helevate.com</li>
<li><span><i class="fa fa-map-marker"></i></span> S/59 Near Bihari Chowk Ramesh Nagar New Delhi 110001 </li>
 </ul>


  </div>
</div>
 
    </div>
</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
